﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecretPlansMark48.Web.Controllers
{
    [AllowAnonymous]
    public class AccessController : Controller
    {
        // GET: Access
        public ActionResult Denied()
        {
            return View();
        }
    }
}